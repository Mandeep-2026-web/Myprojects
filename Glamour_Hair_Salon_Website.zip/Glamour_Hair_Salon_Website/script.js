// ============ PRELOADER ============
window.addEventListener('load', () => {
    const preloader = document.getElementById('preloader');
    setTimeout(() => preloader.classList.add('hide'), 400);
});

// ============ INIT AOS ============
document.addEventListener('DOMContentLoaded', () => {
    if (window.AOS) AOS.init({ duration: 800, once: true, offset: 80 });
});

// ============ NAVBAR SCROLL STYLE + SCROLL PROGRESS ============
const navbar = document.getElementById('mainNav');
const progressBar = document.getElementById('scroll-progress');
const backToTop = document.getElementById('backToTop');

window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    progressBar.style.width = pct + '%';

    navbar.classList.toggle('scrolled', scrollTop > 60);
    backToTop.classList.toggle('show', scrollTop > 400);
});

backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

// ============ ACTIVE NAV LINK ON SCROLL ============
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.navbar-nav .nav-link');

window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(sec => {
        const top = sec.offsetTop - 120;
        if (window.scrollY >= top) current = sec.getAttribute('id');
    });
    navLinks.forEach(link => {
        link.classList.toggle('active', link.getAttribute('href') === '#' + current);
    });
});

// Close mobile menu after clicking a link
document.querySelectorAll('.navbar-nav .nav-link, .navbar .button').forEach(link => {
    link.addEventListener('click', () => {
        const collapseEl = document.getElementById('navMenu');
        if (collapseEl.classList.contains('show')) {
            bootstrap.Collapse.getOrCreateInstance(collapseEl).hide();
        }
    });
});

// ============ SERVICE FILTER ============
const filterBtns = document.querySelectorAll('.filter-btn');
const serviceCards = document.querySelectorAll('.service-card');

filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filter = btn.dataset.filter;
        serviceCards.forEach(card => {
            const show = filter === 'all' || card.dataset.cat === filter;
            card.classList.toggle('filtered-out', !show);
        });
    });
});

// ============ COUNTER ANIMATION ============
const counters = document.querySelectorAll('.counter');
let countersStarted = false;

function animateCounters() {
    counters.forEach(counter => {
        const target = +counter.dataset.target;
        let count = 0;
        const step = Math.max(target / 80, 1);
        const update = () => {
            count += step;
            if (count < target) {
                counter.innerText = Math.ceil(count).toLocaleString();
                requestAnimationFrame(update);
            } else {
                counter.innerText = target.toLocaleString() + (target >= 100 ? '+' : '');
            }
        };
        update();
    });
}

const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !countersStarted) {
            countersStarted = true;
            animateCounters();
        }
    });
}, { threshold: 0.4 });

const heroStats = document.querySelector('.hero-mini-stats');
if (heroStats) statsObserver.observe(heroStats);

// ============ BOOKING FORM VALIDATION ============
const bookingForm = document.getElementById('bookingForm');
if (bookingForm) {
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!bookingForm.checkValidity()) {
            bookingForm.classList.add('was-validated');
            return;
        }
        document.getElementById('formSuccess').classList.remove('d-none');
        bookingForm.reset();
        bookingForm.classList.remove('was-validated');
        setTimeout(() => document.getElementById('formSuccess').classList.add('d-none'), 5000);
    });
}
